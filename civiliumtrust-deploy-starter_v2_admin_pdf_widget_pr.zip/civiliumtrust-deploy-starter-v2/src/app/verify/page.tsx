'use client'
import { useState } from 'react'
export default function VerifyPage(){
  const [serial, setSerial] = useState('')
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string|undefined>()
  async function onSubmit(e:any){
    e.preventDefault()
    setLoading(true); setError(undefined)
    try {
      const res = await fetch(`/api/verify?serial=${encodeURIComponent(serial)}`)
      if(!res.ok) throw new Error('Lookup failed')
      const j = await res.json()
      setData(j)
    } catch (err:any){
      setError(err.message); setData(null)
    } finally { setLoading(false) }
  }
  return (
    <main>
      <h1 className="gold" style={{fontSize:36}}>Verify a Certificate</h1>
      <form onSubmit={onSubmit} style={{display:'flex', gap:8, marginTop:12}}>
        <input value={serial} onChange={e=>setSerial(e.target.value)} placeholder="CT-PL-2025-000128" style={{flex:1}}/>
        <button className="btn" disabled={loading}>{loading?'Checking…':'Verify'}</button>
      </form>
      {error && <p style={{color:'#ff8080', marginTop:12}}>{error}</p>}
      {data && (<div className="card" style={{marginTop:16}}>
          <h3>Result</h3>
          {data.serial ? (<ul>
              <li><strong>Serial:</strong> {data.serial}</li>
              <li><strong>Level:</strong> {data.level}</li>
              <li><strong>Status:</strong> {data.status}</li>
              <li><strong>Expires:</strong> {data.expires_at || '—'}</li>
            </ul>) : <p>No record found.</p>}
        </div>)}
    </main>
  )
}
