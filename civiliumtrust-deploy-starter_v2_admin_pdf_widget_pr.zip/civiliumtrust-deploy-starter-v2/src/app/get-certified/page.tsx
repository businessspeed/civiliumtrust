export default function Page(){
  return (
    <main>
      <h1 className="gold" style={{fontSize:36}}>Get Certified</h1>
      <p style={{opacity:.9}}>Request your certification slot. We audit across ethics, security and transparency. Limited slots per month to protect quality.</p>
      <div className="card" style={{marginTop:16}}>
        <h3>Levels</h3>
        <ul><li>Bronze — Entry</li><li>Silver — Mature</li><li>Gold — Advanced</li><li><strong>Platinum — AI Pro</strong></li></ul>
      </div>
      <div className="card" style={{marginTop:16}}>
        <h3>Apply</h3>
        <p>Use your preferred form provider and send a webhook to our workflow which creates an org & draft certificate in Supabase.</p>
        <p>For now, email: <a href="mailto:cert@civiliumtrust.com">cert@civiliumtrust.com</a></p>
      </div>
    </main>
  )
}
