'use client'
import { useState } from 'react'
export default function Admin(){
  const [pw, setPw] = useState('')
  const [ok, setOk] = useState(false)
  async function login(e:any){ e.preventDefault(); const r = await fetch('/api/admin/auth', { method:'POST', body: JSON.stringify({ pw }) }); setOk(r.ok) }
  if(!ok) return (<main><h1>Admin</h1><form onSubmit={login} style={{display:'flex', gap:8}}><input value={pw} onChange={e=>setPw(e.target.value)} type="password" placeholder="Password"/><button className="btn">Enter</button></form></main>)
  async function issue(e:any){ e.preventDefault(); const f=new FormData(e.currentTarget); const p={ org_name:f.get('org_name'), domain:f.get('domain'), level:f.get('level'), issued:f.get('issued'), expires:f.get('expires') }; const r=await fetch('/api/admin/issue',{method:'POST',headers:{'x-admin':pw},body:JSON.stringify(p)}); alert(await r.text())}
  async function revoke(e:any){ e.preventDefault(); const f=new FormData(e.currentTarget); const p={ serial:f.get('serial'), reason:f.get('reason') }; const r=await fetch('/api/admin/revoke',{method:'POST',headers:{'x-admin':pw},body:JSON.stringify(p)}); alert(await r.text())}
  return (<main style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:24}}>
    <section className="card"><h2>Issue Certificate</h2>
      <form onSubmit={issue} style={{display:'grid', gap:8}}>
        <input name="org_name" placeholder="Organization Name" required/>
        <input name="domain" placeholder="domain.com" required/>
        <select name="level" defaultValue="Platinum"><option>Bronze</option><option>Silver</option><option>Gold</option><option>Platinum</option></select>
        <input name="issued" type="date" required/><input name="expires" type="date"/>
        <button className="btn">Issue</button>
      </form></section>
    <section className="card"><h2>Revoke Certificate</h2>
      <form onSubmit={revoke} style={{display:'grid', gap:8}}>
        <input name="serial" placeholder="CT-PL-2025-000001" required/>
        <input name="reason" placeholder="Reason"/>
        <button className="btn">Revoke</button>
      </form></section>
  </main>)
}
