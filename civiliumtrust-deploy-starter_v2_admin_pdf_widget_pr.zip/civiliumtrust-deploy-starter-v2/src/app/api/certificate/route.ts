import { NextRequest, NextResponse } from 'next/server'
import QRCode from 'qrcode'
function esc(s:string){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') }
export async function GET(req: NextRequest){
  const { searchParams } = new URL(req.url); const serial = searchParams.get('serial'); if(!serial) return new NextResponse('Missing serial', { status: 400 })
  const r = await fetch(`${process.env.SUPABASE_URL}/rest/v1/certificate_public?serial=eq.${encodeURIComponent(serial)}`, { headers:{ apikey: process.env.SUPABASE_ANON_KEY || '', Authorization: `Bearer ${process.env.SUPABASE_ANON_KEY}` }})
  const data = (await r.json())?.[0]; if(!data) return new NextResponse('Not found', { status: 404 })
  const qr = await QRCode.toString(`${process.env.NEXT_PUBLIC_SITE_URL}/verify?serial=${encodeURIComponent(serial)}`, { type:'svg' })
  const svg = `<!doctype html><svg xmlns='http://www.w3.org/2000/svg' width='1123' height='794' viewBox='0 0 1123 794'>
  <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='#E7D3A1'/><stop offset='60%' stop-color='#CBAF7A'/><stop offset='100%' stop-color='#8C6B2B'/></linearGradient>
  <style>.t{font:400 18px Inter,Arial}.b{font-weight:700}.h{font:700 30px Inter,Arial}</style></defs>
  <rect x='8' y='8' width='1107' height='778' fill='white' stroke='url(#g)' stroke-width='16' rx='12'/>
  <text x='80' y='120' class='h' fill='#0B0D10'>Certificate of Digital Trust</text>
  <text x='80' y='160' class='t'>Issued by CIVILIUM TRUST™</text>
  <text x='80' y='230' class='t'>Trust Level: <tspan class='b'>${esc(data.level)}</tspan></text>
  <text x='80' y='270' class='t'>Serial: ${esc(serial)}</text>
  <text x='80' y='310' class='t'>Status: ${esc(data.status)}</text>
  <text x='80' y='350' class='t'>Expires: ${esc(data.expires_at || '—')}</text>
  <image href='/assets/seal_gold.svg' x='80' y='430' width='180' height='180'/>
  <image href='/assets/seal_ai_certified_pro_red.svg' x='940' y='520' width='110' height='110'/>
  <g transform='translate(900,120) scale(0.6)'>${qr}</g>
  <text x='80' y='680' class='t'>Verify: ${esc(process.env.NEXT_PUBLIC_SITE_URL || '')}/verify?serial=${esc(serial)}</text></svg>`
  return new NextResponse(svg, { headers: { 'Content-Type':'image/svg+xml' } })
}
