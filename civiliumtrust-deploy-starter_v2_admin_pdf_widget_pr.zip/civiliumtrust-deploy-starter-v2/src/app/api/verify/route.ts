import { NextRequest, NextResponse } from 'next/server'
export async function GET(req: NextRequest){
  const { searchParams } = new URL(req.url)
  const serial = searchParams.get('serial')
  if(!serial) return NextResponse.json({error:'Missing serial'}, { status: 400 })
  const url = `${process.env.SUPABASE_URL}/rest/v1/certificate_public?serial=eq.${encodeURIComponent(serial)}`
  const res = await fetch(url, { headers: { apikey: process.env.SUPABASE_ANON_KEY || '', Authorization: `Bearer ${process.env.SUPABASE_ANON_KEY}` } })
  if(!res.ok) return NextResponse.json({error:'Lookup failed'}, { status: 502 })
  const data = await res.json()
  return NextResponse.json(data?.[0] ?? {})
}
