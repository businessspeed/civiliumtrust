import { NextRequest, NextResponse } from 'next/server'
export async function POST(req: NextRequest){
  const pw = req.headers.get('x-admin') || ''
  if(pw !== process.env.ADMIN_PASSWORD) return new NextResponse('Forbidden', { status: 403 })
  const body = await req.json().catch(()=>null)
  if(!body) return new NextResponse('Bad Request', { status: 400 })
  const { serial, reason } = body
  const url = `${process.env.SUPABASE_URL}/rest/v1/rpc/revoke_certificate`
  const res = await fetch(url, { method: 'POST', headers: { apikey: process.env.SUPABASE_SERVICE_ROLE_KEY || '', Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_serial: serial, p_reason: reason || 'No reason provided' }) })
  const j = await res.json().catch(()=>({}))
  if(!res.ok) return NextResponse.json(j, { status: 500 })
  return NextResponse.json(j)
}
