import { NextResponse } from 'next/server'
export async function POST(req: Request){
  const body = await req.json().catch(()=>({}))
  if(!body?.pw) return new NextResponse('Missing', { status: 400 })
  if(body.pw !== process.env.ADMIN_PASSWORD) return new NextResponse('Forbidden', { status: 403 })
  return new NextResponse('OK')
}
