import { NextRequest, NextResponse } from 'next/server'
export async function POST(req: NextRequest){
  const pw = req.headers.get('x-admin') || ''
  if(pw !== process.env.ADMIN_PASSWORD) return new NextResponse('Forbidden', { status: 403 })
  const body = await req.json().catch(()=>null)
  if(!body) return new NextResponse('Bad Request', { status: 400 })
  const { org_name, domain, level, issued, expires } = body
  const url = `${process.env.SUPABASE_URL}/rest/v1/rpc/issue_certificate`
  const res = await fetch(url, { method: 'POST', headers: { apikey: process.env.SUPABASE_SERVICE_ROLE_KEY || '', Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_org_name: org_name, p_domain: domain, p_level: level, p_issued: issued, p_expires: expires || null }) })
  const j = await res.json().catch(()=>({}))
  if(!res.ok) return NextResponse.json(j, { status: 500 })
  return NextResponse.json(j)
}
