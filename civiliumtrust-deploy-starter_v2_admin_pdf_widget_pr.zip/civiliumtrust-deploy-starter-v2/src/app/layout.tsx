import './styles/globals.css'
import { ReactNode } from 'react'
import { DefaultSeo } from 'next-seo'

export const metadata = {
  title: 'CIVILIUM TRUST™ — Global Digital Trust Starts Here',
  description: 'Verify once. Trust everywhere. On-chain certificates and live registry.'
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <DefaultSeo titleTemplate="%s | CIVILIUM TRUST™" openGraph={{ type: 'website', site_name: 'CIVILIUM TRUST' }} />
        <div style={{maxWidth:1280, margin:'0 auto', padding:'24px'}}>
          <header style={{display:'flex', alignItems:'center', gap:16, padding:'12px 0'}}>
            <img src="/assets/monogram_ct.svg" alt="CT" width={36} height={36}/>
            <strong className="gold" style={{fontSize:18, letterSpacing:2}}>CIVILIUM TRUST</strong>
            <nav style={{marginLeft:'auto', display:'flex', gap:16}}>
              <a href="/" className="btn">Home</a>
              <a href="/get-certified" className="btn">Get Certified</a>
              <a href="/verify" className="btn">Verify</a>
              <a href="/admin" className="btn">Admin</a>
            </nav>
          </header>
          {children}
          <footer style={{opacity:.8, borderTop:'1px solid #2a2f36', marginTop:48, paddingTop:16}}>
            <div style={{display:'flex', justifyContent:'space-between'}}>
              <div>© {new Date().getFullYear()} CIVILIUM TRUST — Global Digital Standard</div>
              <div style={{display:'flex', gap:16}}>
                <a href="/legal/privacy">Privacy</a>
                <a href="/legal/terms">Terms</a>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  )
}
