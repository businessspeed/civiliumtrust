export default function Page(){
  return (
    <main>
      <section className="card" style={{display:'grid', gridTemplateColumns:'1.2fr 1fr', gap:24, alignItems:'center'}}>
        <div>
          <h1 className="gold" style={{fontSize:48, letterSpacing:1}}>Global Digital Trust Starts Here.</h1>
          <p style={{opacity:.9, marginTop:12}}>Verify once, trust everywhere. CIVILIUM TRUST™ certifies brands, products and AI systems against strict ethical and security standards.</p>
          <div style={{display:'flex', gap:12, marginTop:18}}>
            <a className="btn" href="/get-certified">Get Certified</a>
            <a className="btn" href="/verify">Verify a Certificate</a>
          </div>
        </div>
        <div>
          <img src="/assets/banner_1920x1080.svg" alt="Hero visual" style={{width:'100%', borderRadius:12}}/>
        </div>
      </section>
    </main>
  )
}
