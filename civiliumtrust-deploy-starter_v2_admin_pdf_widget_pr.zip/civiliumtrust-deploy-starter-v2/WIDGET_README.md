# CIVILIUM TRUST — Embeddable Verify Widget
Badge:
<script src="https://your-domain/widget/ct-verify.js" data-mode="badge" data-serial="CT-PL-2025-000128" data-endpoint="https://your-domain/api/verify"></script>
Search:
<script src="https://your-domain/widget/ct-verify.js" data-mode="search" data-endpoint="https://your-domain/api/verify"></script>
