# CIVILIUM TRUST™ — Deploy Starter v2

Next.js 14 + Supabase with Admin (issue/revoke), Verify widget, Certificate SVG endpoint, hardened schema (RLS+view+RPC), PR kit.

Quick start:
1) `npm i`
2) copy `.env.example` → `.env.local` and fill `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_SITE_URL`, `ADMIN_PASSWORD`
3) Supabase → run `supabase/schema.sql`; deploy edge functions `verify`, `qrcode`.
4) `npm run dev` → open `/verify`, `/admin`.
5) Vercel deploy + add env vars.
